-----------------------------------------------------------------------------------------
--
-- main.lua
-- Created by: Ms Raffin
-- Date: Nov. 22nd, 2014
-- Description: This calls the splash screen of the app to load itself.
-----------------------------------------------------------------------------------------

-- Hiding Status Bar
display.setStatusBar( display.HiddenStatusBar )

-----------------------------------------------------------------------------------------

-- Calling libraries
local composer = require( "composer" )

-----------------------------------------------------------------------------------------

-- Put all global variables here that you will need to use throughout the game, such as score.

-----------------------------------------------------------------------------------------

-- Go to the intro screen
composer.gotoScene( "splash_screen" )